import pygame
import random
import time
import os

#Lucien
#Sauvegarde les données de dico dans nomfichier
def save(dico, nomfichier):
    #Ouverture du fichier de sauvegarde en mode ecriture (Création si inexistant)
    fichier = open(nomfichier, "w")
    
    #Liste des clés du dictionnaire des données à sauvegarder
    liste_keys = list(dico.keys())
    
    #Creation de la chaine de caractère (toutes les données concaténées) à sauvegarder
    save_str = ""
    for key in liste_keys:
        str_add = "\n"#Fin de ligne
        sep = "²"#Séparation pour l'utilisation ultérieure d'un load()
        if dico[key] == "style":
            pass
        else:
            type_str = str(type(dico[key]))[8:-2]#Stockage du type de donnée associé à key
        
        #chaque ligne aura une clé (key) suivi du type de la donnée (type_str) suivi de la donnée convertie en string. Chaque information est séparé par sep (²)
        save_str += key + sep + type_str + sep + str(dico[key]) + str_add
    
    #Ecriture dans le fichier save puis fermeture
    fichier.write(save_str)
    fichier.close()

#Lucien
#Charge les données de nomfichier dans dico
#liste_dico correspond aux styles
def load(dico, nomfichier, liste_dico):
    #Ouverture du fichier de sauvegarde
    fichier = open(nomfichier, "r")
    
    #Stockage des données du fichier puis fermeture
    liste_donnees_brut = fichier.readlines()
    fichier.close()
    
    #Formatage des données et ajout dans le dictionnaire
    liste_donnees_affinee = [e.strip().split('²') for e in liste_donnees_brut]
    for cle, type_str, donnee in liste_donnees_affinee:
        if type_str == 'int':
            donnee = int(donnee)
        elif type_str == 'float':
            donnee = float(donnee)
        elif type_str == 'tuple':
            if donnee == '()':
                donnee = ()
            else:
                donnee = tuple([int(e) for e in donnee[1:-1].split(',')])
        elif type_str == 'list':
            if donnee == '[]':
                donnee = []
            else:
                donnee = list([int(e) for e in donnee[1:-1].split(',')])
        elif type_str == 'str':
            if donnee == "classique":
                donnee = liste_dico[0]
            elif donnee == "chompagne":
                donnee = liste_dico[1]
            elif donnee == "chompignon":
                donnee = liste_dico[2]
            else:
                print(f"Erreur de chargement : {donnee} n'est pas sensé être sauvegardé")
        dico[cle] = donnee

#Lucien
#Affiche un menu contenant tout les bouttons de la liste répartis de manière équitable sur l'ecran
def afficher_menu(liste_img, screen_size, buttons_size, screen, offset = 0, img_title = None, img_subtitle = None, img_subtitle_size = None, modif_size = False, font = None, largeur = None, hauteur = None, valeur3 = None, pos_1 = None, pos_2 = None, pos_3 = None, offset_text = None, offset_text_spe = None, img_selection_spe = None, selection_speciale = False, pos_selection_spe = None):
    liste_pos = []
    if img_title != None:
        screen.blit(img_title, (0, 0 - 281 / 4))
    if img_subtitle != None:
        screen.blit(img_subtitle, ((screen_size[0] - img_subtitle_size[0]) / 2, img_subtitle_size[1] / 6))
    for i in range(len(liste_img)):
        liste_pos.append((screen_size[0] / 2 - buttons_size[0] / 2, ((screen_size[1] - offset) / (len(liste_img) + 1)) * (i + 1) - buttons_size[1] / 2 + offset))
        screen.blit(liste_img[i], liste_pos[i])
        if selection_speciale and i == pos_selection_spe:
            screen.blit(img_selection_spe, liste_pos[i])
        if modif_size:
            pos = (liste_pos[i][0] + offset_text, liste_pos[i][1] + 10)
            if i == pos_1:
                text_largeur = font.render(str(largeur), True, (0, 0, 0))
                screen.blit(text_largeur, pos)
            elif i == pos_2:
                text_hauteur = font.render(str(hauteur), True, (0, 0, 0))
                screen.blit(text_hauteur, pos)
            elif i == pos_3:
                pos = (liste_pos[i][0] + offset_text_spe, liste_pos[i][1] + 10)
                text_valeur3 = font.render(str(valeur3), True, (0, 0, 0))
                screen.blit(text_valeur3, pos)
    return liste_pos

#Lucien
#Afficher la selection spécifique aux menus
def afficher_selection_menu(img, selection, liste_pos, screen_size, buttons_size, screen, offset = 10):
    screen.blit(img, (screen_size[0] / 2 - buttons_size[0] / 2 - offset - 16, liste_pos[selection][1] + buttons_size[1] / 2 - 8))
    screen.blit(pygame.transform.rotate(img, 180), (screen_size[0] / 2 + buttons_size[0] / 2 + offset, liste_pos[selection][1] + buttons_size[1] / 2 - 8))

#Lucien
#Afficher la selection spécifique à la map
def afficher_selection_map(selection, img, screen, cases_size, offset = (10, 10), sep = (0, 0)):
    pos_x = offset[0] + selection[0] * cases_size[0] + sep[0]
    pos_y = offset[1] + selection[1] * cases_size[1] + sep[1]
    screen.blit(img, (pos_x, pos_y))

#Lucien
#Afficher le tour humain
def tour_humain(cases, cases_suppr, poison_img, screen, screen_size, fond, pos_fond, offset, selection_map, selection_img, font, jouer, map, img_last_move):
    taille_case = cases.get_size()
    screen.blit(fond, pos_fond)
    aff_map(map, screen, cases, cases_suppr, poison_img, img_last_move, taille_case, jouer, offset)
    afficher_selection_map(selection_map, pygame.transform.scale(selection_img, (taille_case[0], taille_case[1])), screen, cases.get_size())
    text = font.render(f"Joueur {jouer['Joueur']} : Choisir une case", True, (0, 0, 0))
    textRect = text.get_rect()
    screen.blit(text, (screen_size[0] / 2 - textRect.width / 2, 400))

#Lucien
#Afficher le tour ia et fais le choix de la case en fonction de sa difficulté
def tour_ia(cases, cases_suppr, poison_img, screen, screen_size, fond, pos_fond, offset, selection_img, font, jouer, map, dernier_move, img_last_move, son):
    taille_case = cases.get_size()
    screen.blit(fond, pos_fond)
    if jouer["Difficulté"] == "facile" or (jouer["Mode"] == "ai_vs_ai" and ((jouer["AI 1"] == 1 and jouer["Joueur"] == 1) or (jouer["AI 2"] == 1 and jouer["Joueur"] == 2))):
        selection_map = choix_pos_ia_facile(map)
    else:
        selection_map = choix_pos_ia_moyen_difficile_lucien(map, dernier_move, jouer)
    aff_map(map, screen, cases, cases_suppr, poison_img, img_last_move, taille_case, jouer, offset)
    afficher_selection_map(selection_map, pygame.transform.scale(selection_img, (taille_case[0], taille_case[1])), screen, cases.get_size())
    if jouer["Mode"] == "ai_vs_ai" or jouer["Mode"] == "solo" or (jouer["Mode"] == "bac_a_sable" and jouer["Mode_Jc"] == "JcE"):
        if jouer["Mode"] == "ai_vs_ai":
            text = font.render(f"L'IA {jouer['Joueur']} est en train de jouer", True, (0, 0, 0))
        else:
            if jouer["Joueur"] == 2:
                text = font.render(f"L'IA {jouer['Joueur']} est en train de jouer", True, (0, 0, 0))
            else:
                text = font.render(f"Joueur {jouer['Joueur']} est en train de jouer", True, (0, 0, 0))
    else:
        text = font.render(f"Joueur {jouer['Joueur']} est en train de jouer", True, (0, 0, 0))
    textRect = text.get_rect()
    screen.blit(text, (screen_size[0] / 2 - textRect.width / 2, 400))
    jouer["last_move"] = valider_un_tour(map, selection_map, jouer, son)

#Lucien
#Modifier la map en fonction de la seletion puis verifier si game over
#Gere egalement l'alternance des tours des joueurs
def valider_un_tour(map, selection_map, jouer, son):
    modifier_map(map, selection_map, jouer)
    if jouer["Fin"] != True:
        son.play()
    if game_over(map):
        if jouer["Fin"] == False:
            son_fin.play()
            if jouer["Mode"] == "solo":
                result = jouer["Joueur"] - 1
                jouer["logs_games"].append(result)
                if jouer["Difficulté"] == "facile":
                    if result == 0:#Defaite
                        elo = -15
                    else:#Victoire
                        elo = 5
                elif jouer["Difficulté"] == "moyen":
                    if result == 0:#Defaite
                        elo = -10
                    else:#Victoire
                        elo = 10
                elif jouer["Difficulté"] == "difficile":
                    if result == 0:#Defaite
                        elo = -5
                    else:#Victoire
                        elo = 15
                jouer["elo"] += elo
        jouer["Fin"] = True
        jouer["win_strat"] = False
        jouer["last_move"] = None
        jouer["logs"] = []
    else:
        jouer["Joueur"] = 3 - jouer["Joueur"]
        jouer["selection_map"] = [0, 0]
        return selection_map

#JM
#Comme son nom l'indique, permet de faire un undo
#Modofie la map (reviens un coup en arriere)
def undo(map, liste_originale, jouer):
    liste = liste_originale[1]
    for pos in liste:
        map[pos[1]][pos[0]] = '0'
    jouer["last_move"] = liste_originale[0]

#JM
#Creer la map
def creer_map(lignes, colonnes): ## Fonction qui créer le tableau
    return [['0' for _ in range(lignes)] for _ in range(colonnes)]

#JM (modifié par Lucien uniquement pour la compatibilité pygame)
#Afficher la map
def aff_map(grille, screen, img_case, img_case_suppr, img_case_empoisonnee, img_last_move, case_size, jouer, offset = (10, 10), sep = (0, 0)): ## fonction qui affiche les listes via la variable grille sous forme de tableau
    #grille_str = ""
    for y in range(len(grille)):
        #ligne_str = ""
        for x in range(len(grille[y])):
            pos_x = offset[0] + x * case_size[0] + sep[0]
            pos_y = offset[1] + y * case_size[1] + sep[1]
            if grille[y][x] == "0":
                img = img_case
            elif grille[y][x] == "X":
                img = img_case_suppr
            screen.blit(img, (pos_x, pos_y))
            if jouer["last_move"] != None and y == jouer["last_move"][1] and x == jouer["last_move"][0]:
                screen.blit(img_last_move, (pos_x, pos_y))
            #ligne_str += cell + " "
            #grille_str += ligne_str + "/n"
            
        #print(ligne_str)
    screen.blit(img_case_empoisonnee, (offset[0] + case_size[0] / 2 - img_case_empoisonnee.get_size()[0] / 2, offset[1]))
   
#JM       
def game_over(grille): ## fonction qui détermine la fin du jeu avec le carreau empoisonné
    return grille[0][0] == "X"

#JM x Lucien
#Modifie la map en fonction de la selection
def modifier_map(map, selection, jouer):
    taille_map_x = len(map[0])
    taille_map_y = len(map)
    selection_x = selection[0]
    selection_y = selection[1]
    #Preparation du stockage des logs
    liste_tmp_global = [(selection[0], selection[1])]
    liste_tmp = []
    #Modifier map
    for x in range(selection_x, taille_map_x):
        for y in range(selection_y, taille_map_y):
            if map[y][x] == '0':
                liste_tmp.append((x, y))
            if map[y][x] == '0':
                map[y][x] = 'X'
    #Stockage des logs
    liste_tmp_global.append(liste_tmp)
    jouer["logs"].append(liste_tmp_global)

#Lucien
#Créé une liste ne comprenant que les cases jouables. Cette liste se presente comme la liste map mais avec des elements en moins.
def modifier_map_pour_ia(map):
    liste = []
    for y in range(len(map)):
        liste_tmp = []
        for x in range(len(map[0])):
            if map[y][x] == '0':
                liste_tmp.append('0')
        if liste_tmp != []:
            liste.append(liste_tmp)
    return liste

#Lucien
#Regarde si il n'y a pas un jeu de nim (une seule ligne ou une seule colonne par exemple)
def verifier_et_modifier_map_to_nim(map):
    nim = False
    if map != [] and len(map[0]) == 1:
        for y in range(len(map)):
            if len(map[y]) == 1:
                nim = True
            else:
                nim = False
    return nim

#Lucien
#L'ia moyen choisis une case aléatoire parmis toute celles jouables sauf si la premiere ligne et la première colonne sont de même longueur auquel cas l'ia choisira le meilleur coup à faire
#L'ia difficile execute la stratégie gagnante pour une partie avec un tableau carré
def choix_pos_ia_moyen_difficile_lucien(map, dernier_move, jouer):
    map_modif = list(modifier_map_pour_ia(map))#Permet a l'ia de regarder la longeur des lignes et colonnes plus facilement (cela lui permet de ne regarder que les cases vides)
    map_modif_nim = verifier_et_modifier_map_to_nim(map_modif)#Vérifie si c'est un jeu de nim sur la premiere colonne
    if map_modif == [] or (len(map_modif) == 1 and len(map_modif[0])) == 1:#Pas d'autre choix que de perdre
        choix = (0, 0)
    elif not(map_modif_nim) and len(map_modif) == 1:#Si c'est un jeu de nim horizontal
        choix = (1, 0)
    elif map_modif_nim:#Si c'est un jeu de nim vertical
        choix = (0, 1)
    elif len(map_modif) == len(map_modif[0]) or jouer["win_strat"]:#Regarde si la colonne de gauche est aussi longue que la premiere ligne
        if dernier_move == None and (jouer["Difficulté"] == "moyen" or ((jouer["AI 1"] == 2 and jouer["Joueur"] == 1) or (jouer["AI 2"] == 2 and jouer["Joueur"] == 2))):#Si c'est le cas et que l'ia commence alors elle prendra une case aleatoire (pour la difficulté moyenne)
            choix = choix_pos_ia_facile(map)
        elif map[1][1] == '0':#Peut importe si elle commence, elle jouera le meilleur coup dans ce cas là (transformer la map en double jeu de nim)
            choix = (1, 1)
            jouer["win_strat"] = True
        elif dernier_move[0] != 1 and dernier_move[1] != 1 and map[dernier_move[0]][dernier_move[1]] == '0':#Elle rentre la dedans si l'humain n'a pas fait le coup gagnant
            choix = (dernier_move[1], dernier_move[0])#Elle joue en mirroir.
            jouer["win_strat"] = True
        else:#Temporise jusqu'a ce que l'humain fasse une erreur mais si ce n'est pas le cas elle perdra
            inshallah = random.randint(1, 2)
            if inshallah == 1:
                choix = (0, len(map_modif) - 1)#Prend la derniere case de la premiere colonne
            else:
                choix = (len(map_modif[0]) - 1, 0)#Prend la derniere case de la permiere ligne
            jouer["win_strat"] = True
    else:#Si la map actuelle est un rectangle
        if jouer["Difficulté"] == "moyen":
            choix = choix_pos_ia_facile(map)
    return choix

#JM
#L'ia facile choisis une case aléatoire parmis toutes celles jouables.
def choix_pos_ia_facile(map):
    positions_valides = []
    for y in range(len(map)):
        for x in range(len(map[y])):
            if map[y][x] == '0' and (y != 0 or x != 0):
                positions_valides.append((x, y))
    
    if positions_valides == []:#Si il n'y a pas de case valides alors prendre la dernière case (empoisonnée)
        choix = (0, 0)
    else:
        choix = random.choice(positions_valides)
    return choix

#JM
#Renvoie un tuple suivant : (premier element = dernier resultat de partie, deuxieme element = nombre de fois ou le premier element s'est répété d'affilé (evidemment en partant de la fin de tous les resultats))
def win_lose_streak(liste):
    i = len(liste) - 2
    dernier_element = liste[-1]
    compteur = 1
    fin = False
    while i >= 0 and not(fin):
        if liste[i] == dernier_element:
            compteur += 1
            i -= 1
        else:
            fin = True
    return (dernier_element, compteur)

#JM
#Calcule le winrate et le met en pourcentage
def ratio_vd(liste): # Fonction ratio victoire/défaite
    
    somme_lv = sum(liste)#0 + 1 + 1 + 0 par exemple
    parties_jouees = len(liste)
    if parties_jouees == 0:
        ratio = 0
    else:
        ratio = somme_lv/parties_jouees
    return round(ratio * 100, 2)

#Lucien
#Prend un entier et regarde a quel niveau de difficulté il correspond
def convertir_ia_diff_to_str(diff):
    if diff == 1:
        ia_str = "facile"
    elif diff == 2:
        ia_str = "moyen"
    else:
        ia_str = "difficile"
    return ia_str

#Lucien
#Modifier les volumes en fontion des paramètres
def modifier_volumes(jouer):
    son_music = jouer["son_music"]
    son_vfx = jouer["son_vfx"]
    pygame.mixer.music.set_volume(son_music)
    son_move_selection.set_volume((0.5 * 2) * son_vfx)
    son_verre.set_volume((0.7 * 2) * son_vfx)
    son_croc.set_volume((0.3 * 2) * son_vfx)
    son_fin.set_volume((0.5 * 2) * son_vfx)
    son_poison.set_volume((0.5 * 2) * son_vfx)
    son_selected.set_volume((0.5 * 2) * son_vfx)
    son_undo.set_volume((0.5 * 2) * son_vfx)

#Initialisation du module pygame
pygame.init()
pygame.mixer.init()

#Stockage informations concernant les tailles
screen_size = (500, 500)
buttons_size = (200, 50)

#Creation de la fenêtre
screen = pygame.display.set_mode(screen_size)
pygame.display.set_caption("CHOMP")

#Importation des assets
#------Sons------
fond_sonor = pygame.mixer.music.load("assets/sounds/MartijnSchmit-VacsInTheMorning.mp3")
# pygame.mixer.music.set_volume(0.2)
son_croc = pygame.mixer.Sound("assets/sounds/Croc.mp3")
# son_croc.set_volume(0.3)
son_fin = pygame.mixer.Sound("assets/sounds/Fin.mp3")
# son_fin.set_volume(0.5)
son_move_selection = pygame.mixer.Sound("assets/sounds/move_selection.mp3")
# son_move_selection.set_volume(0.5)
son_selected = pygame.mixer.Sound("assets/sounds/Select.mp3")
# son_selected.set_volume(0.5)
son_verre = pygame.mixer.Sound("assets/sounds/Verre.mp3")
# son_verre.set_volume(0.7)
son_poison = pygame.mixer.Sound("assets/sounds/Poison.mp3")
# son_poison.set_volume(0.5)
son_undo = pygame.mixer.Sound("assets/sounds/Undo.mp3")
# son_undo.set_volume(0.5)
#------Bouttons------
boutton_jouer_img = pygame.image.load("assets/imgs/Bouton_Jouer.png")
boutton_options_img = pygame.image.load("assets/imgs/Bouton_Options.png")
boutton_stats_img = pygame.image.load("assets/imgs/Bouton_Stats.png")
boutton_quitter_img = pygame.image.load("assets/imgs/Bouton_Quitter.png")
boutton_retour_img = pygame.image.load("assets/imgs/Bouton_Retour.png")
boutton_solo_img = pygame.image.load("assets/imgs/Bouton_Solo.png")
boutton_multi_img = pygame.image.load("assets/imgs/Bouton_Multi.png")
boutton_aivsai_img = pygame.image.load("assets/imgs/Bouton_AIvsAI.png")
boutton_bacasable_img = pygame.image.load("assets/imgs/Bouton_BacASable.png")
boutton_facile_img = pygame.image.load("assets/imgs/Bouton_Facile.png")
boutton_moyen_img = pygame.image.load("assets/imgs/Bouton_Moyen.png")
boutton_difficile_img = pygame.image.load("assets/imgs/Bouton_Difficile.png")
boutton_style_img = pygame.image.load("assets/imgs/Bouton_Style.png")
boutton_suivant_img = pygame.image.load("assets/imgs/Bouton_Suivant.png")
boutton_jcj_img = pygame.image.load("assets/imgs/Bouton_JcJ.png")
boutton_jce_img = pygame.image.load("assets/imgs/Bouton_jce.png")
boutton_largeur_img = pygame.image.load("assets/imgs/Bouton_Largeur.png")
boutton_hauteur_img = pygame.image.load("assets/imgs/Bouton_Hauteur.png")
boutton_taille_img = pygame.image.load("assets/imgs/Bouton_Taille.png")
boutton_ai1_img = pygame.image.load("assets/imgs/Bouton_AI1.png")
boutton_ai2_img = pygame.image.load("assets/imgs/Bouton_AI2.png")
boutton_delai_img = pygame.image.load("assets/imgs/Bouton_Delai.png")
boutton_reset_img = pygame.image.load("assets/imgs/Bouton_Reset.png")
boutton_son_img = pygame.image.load("assets/imgs/Bouton_Son.png")
boutton_son_droite_img = pygame.image.load("assets/imgs/Bouton_Droite.png")
boutton_son_gauche_img = pygame.image.load("assets/imgs/Bouton_Gauche.png")
boutton_son_vide_img = pygame.image.load("assets/imgs/Bouton_son_vide.png")
boutton_son_rempli_img = pygame.image.load("assets/imgs/Bouton_son_rempli.png")
#------Selections------
selection_menu_img = pygame.image.load("assets/imgs/Triangle.png")
selection_map_classique_img = pygame.image.load("assets/imgs/selection_classique.png")
selection_map_chompagne_img = pygame.image.load("assets/imgs/chompagne_selection.png")
selection_map_chompignon_img = pygame.image.load("assets/imgs/chompignon_selection.png")
selection_bouttons_img = pygame.image.load("assets/imgs/Bouton_selection.png")
#------Images------
chomp3D_img = pygame.image.load("assets/imgs/Chomp3D_modif.png")
chomp3D_img = pygame.transform.scale(chomp3D_img, (500, 281))
agne3D_img = pygame.image.load("assets/imgs/Agne3D_2_modif.png")
agne3D_size = (400, 225)
agne3D_img = pygame.transform.scale(agne3D_img, agne3D_size)
ignon3D_img = pygame.image.load("assets/imgs/Ignon3D_2_modif.png")
ignon3D_size = (400, 225)
ignon3D_img = pygame.transform.scale(ignon3D_img, ignon3D_size)
classique_img = pygame.image.load("assets/imgs/Classique3D_modif.png")
classique_size = (400, 225)
classique_img = pygame.transform.scale(classique_img, classique_size)
chocolat_img = pygame.image.load("assets/imgs/carreau.png")
chocolat_suppr_img = pygame.image.load("assets/imgs/carreau_suppr.png")
chocolat_poison_img = pygame.image.load("assets/imgs/carreau_poison.png")
champagne_img = pygame.image.load("assets/imgs/Champagne.png")
champagne_suppr_img = pygame.image.load("assets/imgs/champagne_suppr.png")
champagne_poison_img = pygame.image.load("assets/imgs/champagne_poison.png")
champignon_img = pygame.image.load("assets/imgs/Champignon.png")
champignon_suppr_img = pygame.image.load("assets/imgs/champignon_suppr.png")
champignon_poison = pygame.image.load("assets/imgs/champignon_poison.png")
classique_style_img = pygame.image.load("assets/imgs/Classique_style.png")
chompignon_style_img = pygame.image.load("assets/imgs/Chompignon_style.png")
chompagne_style_img = pygame.image.load("assets/imgs/Chompagne_style.png")
fond_classique_img = pygame.image.load("assets/imgs/fond_Classique.png")
fond_chompagne_img = pygame.image.load("assets/imgs/fond_Chompagne.png")
fond_chompignon_img = pygame.image.load("assets/imgs/fond_Chompignon.png")
classique_last_move_img = pygame.image.load("assets/imgs/classique_last_move.png")
chompagne_last_move_img = pygame.image.load("assets/imgs/chompagne_last_move.png")
chompignon_last_move_img = pygame.image.load("assets/imgs/chompignon_last_move.png")

#Création des polices d'écriture
pavelt_font = pygame.font.Font("assets/fonts/Pavelt.ttf", 20)

#------Styles------
classique = {
    "titre" : classique_img,
    "titre_size" : classique_size,
    "cases" : chocolat_img,
    "cases_suppr" : chocolat_suppr_img,
    "son_suppr" : son_croc,
    "case_poison" : chocolat_poison_img,
    "last_move_img" : classique_last_move_img,
    "selection" : selection_map_classique_img,
    "fond" : fond_classique_img
}
chompagne = {
    "titre" : agne3D_img,
    "titre_size" : agne3D_size,
    "cases" : champagne_img,
    "cases_suppr" : champagne_suppr_img,
    "son_suppr" : son_verre,
    "case_poison" : champagne_poison_img,
    "last_move_img" : chompagne_last_move_img,
    "selection" : selection_map_chompagne_img,
    "fond" : fond_chompagne_img
}
chompignon = {
    "titre" : ignon3D_img,
    "titre_size" : ignon3D_size,
    "cases" : champignon_img,
    "cases_suppr" : champignon_suppr_img,
    "son_suppr" : son_poison,
    "case_poison" : champignon_poison,
    "last_move_img" : chompignon_last_move_img,
    "selection" : selection_map_chompignon_img,
    "fond" : fond_chompignon_img
}

configs = {}

if os.path.exists("configs.chomp"):
    load(configs, "configs.chomp", [classique, chompagne, chompignon])
else:
    print("Chargement des données par défaut")
    configs = {
       "style" : classique,
       "taille_map" : [5, 5],
       "offset" : (10, 10),
       "limite_y" : 300,
       "delai" : 0.5,
       "logs_games" : [],
       "winrate" : 0,
       "streak" : (),
       "elo" : 0,
       "son_music" : 0.7,
       "son_vfx" : 0.5
    }

#Indique si le jeu dois tourner ou non
running = True

#Initialisation des variables
map = [[0, 0],[0, 0]]#Uniquement pour initialiser selection_map
selection_menu = 0
menu = "main"
liste_pos = []
stats = False
menu_son = False
pos_fond = [-64, -64]
speed = 0.25

#Limiter les fps (vitesse de passage dans le main while)
clock = pygame.time.Clock()

#Savoir si on lance le jeu + infos complementaires
jouer = {"En jeu" : False,
         "Mode" : None,
         "Mode_Jc" : "JcJ",
         "AI 1" : 1,
         "AI 2" : 1,
         "Difficulté" : None,
         "Premier lancement" : None,
         "Joueur" : None,
         "Fin" : False,
         "Afficher" : False,
         "Afficher_content" : None,
         "last_move" : None,
         "win_strat" : False,
         "selection_map" : [len(map[0]) // 2, len(map) // 2],
         "logs" : [],
         "logs_games" : configs["logs_games"],
         "elo" : configs["elo"],
         "son_music" : configs["son_music"],
         "son_vfx" : configs["son_vfx"]
        }

#Setup les volumes
modifier_volumes(jouer)
pygame.mixer.music.play(-1)

#Main while
while running:
    configs["winrate"] = ratio_vd(jouer["logs_games"])
    #Ralentir le jeu si mode = IA vs IA
    if jouer["En jeu"] == True and jouer["Mode"] == "ai_vs_ai" and jouer["Fin"] == False:
        time.sleep(configs["delai"])
    
    #Recuperer les events qui pourraient survenir
    for event in pygame.event.get():
        #Lorsque l'utilisateur veux quitter, sortir de la boucle
        if event.type == pygame.QUIT:
            running = False
        
        #Capter les evenements de touches pressées et agir en conséquence
        if event.type == pygame.KEYDOWN:
            #------Mouvement------
            #Ne pas sortir de la map ni aller sur une case non valide
            if event.key == pygame.K_LEFT and ((menu == "empty" and jouer["selection_map"][0] > 0) or menu_son):
                if menu_son and selection_menu == 0:
                    if jouer["son_music"] != 0:
                        son_selected.play()
                    if jouer["son_music"] - 0.125 < 0:
                        jouer["son_music"] = 0
                    else:
                        jouer["son_music"] -= 0.125
                elif menu_son and selection_menu == 1:
                    if jouer["son_vfx"] != 0:
                        son_selected.play()
                    if jouer["son_vfx"] - 0.125 < 0:
                        jouer["son_vfx"] = 0
                    else:
                        jouer["son_vfx"] -= 0.125
                elif not(menu_son):
                    jouer["selection_map"][0] -= 1
            if event.key == pygame.K_RIGHT and ((menu == "empty" and jouer["selection_map"][0] < len(map[0]) - 1 and map[jouer["selection_map"][1]][jouer["selection_map"][0] + 1] != 'X') or menu_son):
                if menu_son and selection_menu == 0:
                    if jouer["son_music"] != 1:
                        son_selected.play()
                    if jouer["son_music"] + 0.125 > 1:
                        jouer["son_music"] = 1
                    else:
                        jouer["son_music"] += 0.125
                elif menu_son and selection_menu == 1:
                    if jouer["son_vfx"] != 1:
                        son_selected.play()
                    if jouer["son_vfx"] + 0.125 > 1:
                        jouer["son_vfx"] = 1
                    else:
                        jouer["son_vfx"] += 0.125
                elif not(menu_son):
                    jouer["selection_map"][0] += 1
            if event.key == pygame.K_UP:
                if menu != "empty" and selection_menu > 0:
                    selection_menu -= 1
                    son_move_selection.play()
                elif jouer["selection_map"][1] > 0:
                    jouer["selection_map"][1] -= 1
            if event.key == pygame.K_DOWN:
                if menu != "empty" and selection_menu < len(liste_pos) - 1:
                    selection_menu += 1
                    son_move_selection.play()
                elif jouer["selection_map"][1] < len(map) - 1 and map[jouer["selection_map"][1] + 1][jouer["selection_map"][0]] != 'X':
                    jouer["selection_map"][1] += 1
            #------Valider------
            #Changer de menu
            if event.key in (pygame.K_KP_ENTER, pygame.K_RETURN):
                if menu != "empty":
                    son_selected.play()
                    if menu == "main":
                        if selection_menu == 0:#Jouer
                            menu = "play"
                            selection_menu = 0
                        elif selection_menu == 1:#Options
                            menu = "options"
                            selection_menu = 0
                        elif selection_menu == 2:#Stats
                            menu = "stats"
                            stats = True
                            selection_menu = 0
                        elif selection_menu == 3:#Quitter
                            menu = "empty"
                            running = False
                    elif menu == "play":
                        if selection_menu == 0:#Solo
                            menu = "difficulties"
                            selection_menu = 0
                        elif selection_menu == 1:#Multi
                            menu = "empty"
                            jouer["En jeu"] = True
                            jouer["Mode"] = "multi"
                            jouer["Premier lancement"] = True
                            jouer["Joueur"] = 1
                            selection_menu = 0
                        elif selection_menu == 2:#AI vs AI
                            menu = "ai_vs_ai"
                            selection_menu = 0
                        elif selection_menu == 3:#Bac à sable
                            menu = "bac_a_sable"
                            selection_menu = 0
                        elif selection_menu == 4:#Retour
                            menu = "main"
                            selection_menu = 0
                    elif menu == "difficulties":
                        if selection_menu == 0:#Taille de la mpa (carré)
                            if configs["taille_map"][0] == 7:
                                configs["taille_map"][0] = 2
                            else:
                                configs["taille_map"][0] += 1
                        elif selection_menu == 1:#Facile
                            jouer["En jeu"] = True
                            jouer["Mode"] = "solo"
                            jouer["Difficulté"] = "facile"
                            jouer["Premier lancement"] = True
                            jouer["Joueur"] = random.randint(1, 2)
                            menu = "empty"
                            selection_menu = 0
                        elif selection_menu == 2:#Moyen
                            jouer["En jeu"] = True
                            jouer["Mode"] = "solo"
                            jouer["Difficulté"] = "moyen"
                            jouer["Premier lancement"] = True
                            jouer["Joueur"] = random.randint(1, 2)
                            menu = "empty"
                            selection_menu = 0
                        elif selection_menu == 3:#Difficile
                            jouer["En jeu"] = True
                            jouer["Mode"] = "solo"
                            jouer["Difficulté"] = "difficile"
                            jouer["Premier lancement"] = True
                            jouer["Joueur"] = random.randint(1, 2)
                            menu = "empty"
                            selection_menu = 0
                        elif selection_menu == 4:#Retour
                            menu = "play"
                            selection_menu = 0
                    elif menu == "options":
                        if selection_menu == 0:#Son
                            menu = "son"
                            menu_son = True
                            selection_menu = 0
                        elif selection_menu == 1:#Style
                            menu = "styles"
                            selection_menu = 0
                        elif selection_menu == 2:#Largeur
                            if configs["taille_map"][0] == 7:
                                configs["taille_map"][0] = 2
                            else:
                                configs["taille_map"][0] += 1
                        elif selection_menu == 3:#Hauteur
                            if configs["taille_map"][1] == 7:
                                configs["taille_map"][1] = 2
                            else:
                                configs["taille_map"][1] += 1
                        elif selection_menu == 4:
                            if configs["delai"] == 2:
                                configs["delai"] = 0
                            else:
                                configs["delai"] += 0.5
                        elif selection_menu == 5:#Retour
                            menu = "main"
                            selection_menu = 0
                    elif menu == "stats":
                        if selection_menu == 0:#Reset
                            configs["winrate"] = 0
                            configs["logs_games"] = []
                            configs["streak"] = ()
                            jouer["logs_games"] = []
                            jouer["elo"] = 0
                        if selection_menu == 1:#Retour
                            menu = "main"
                            stats = False
                            selection_menu = 0
                    elif menu == "fin":
                        if selection_menu == 0:#Suivant
                            jouer["En jeu"] = False
                            jouer["Mode"] = None
                            jouer["Afficher"] = False
                            jouer["Fin"] = False
                            menu = "main"
                            selection_menu = 0
                    elif menu == "bac_a_sable":
                        if selection_menu == 0:#JCJ
                            jouer["Mode_Jc"] = "JcJ"
                        elif selection_menu == 1:#JCE
                            jouer["Mode_Jc"] = "JcE"
                        elif selection_menu == 2:#Largeur
                            if configs["taille_map"][0] == 7:
                                configs["taille_map"][0] = 2
                            else:
                                configs["taille_map"][0] += 1
                        elif selection_menu == 3:#Hauteur
                            if configs["taille_map"][1] == 7:
                                configs["taille_map"][1] = 2
                            else:
                                configs["taille_map"][1] += 1
                        elif selection_menu == 4:#Suivant:
                            menu = "empty"
                            jouer["En jeu"] = True
                            jouer["Mode"] = "bac_a_sable"
                            jouer["Difficulté"] = "facile"
                            jouer["Premier lancement"] = True
                            jouer["Joueur"] = random.randint(1, 2)
                            selection_menu = 0
                        elif selection_menu == 5:
                            menu = "play"
                            selection_menu = 0
                    elif menu == "styles":
                        if selection_menu == 0:#Classique
                            configs["style"] = classique
                            selection_menu = 0
                        elif selection_menu == 1:#Chompagne
                            configs["style"] = chompagne
                            selection_menu = 0
                        elif selection_menu == 2:#Chompignon
                            configs["style"] = chompignon
                            selection_menu = 0
                        elif selection_menu == 3:#Retour
                            menu = "options"
                            selection_menu = 0
                    elif menu == "ai_vs_ai":
                        if selection_menu == 0:#IA 1 diff
                            if jouer["AI 1"] == 3:
                                jouer["AI 1"] = 1
                            else:
                                jouer["AI 1"] += 1
                        elif selection_menu == 1:#IA 2 diff
                            if jouer["AI 2"] == 3:
                                jouer["AI 2"] = 1
                            else:
                                jouer["AI 2"] += 1
                        elif selection_menu == 2:#Suivant
                            menu = "empty"
                            jouer["En jeu"] = True
                            jouer["Premier lancement"] = True
                            jouer["Mode"] = "ai_vs_ai"
                            jouer["Joueur"] = random.randint(1, 2)
                            selection_menu = 0
                        elif selection_menu == 3:#Retour
                            menu = "play"
                            selection_menu = 0
                    elif menu == "son":
                        if selection_menu == 2:#Retour
                            menu = "options"
                            menu_son = False
                            selection_menu = 0
                else:#Valider
                    jouer["last_move"] = valider_un_tour(map, jouer["selection_map"], jouer, configs["style"]["son_suppr"])
            #------Undo------
            if event.key == pygame.K_BACKSPACE and jouer["Mode"] == "bac_a_sable":
                if jouer["logs"] != []:
                    undo(map, jouer["logs"].pop(), jouer)
                    son_undo.play()
    #Gestion du jeu
    if jouer["En jeu"]:
        #Si début de la partie
        if jouer["Premier lancement"]:
            #Definition de la taille de la map
            largeur = configs["taille_map"][0]
            if jouer["Mode"] == "solo" or jouer["Mode"] == "ai_vs_ai":
                hauteur = largeur
            else:
                hauteur = configs["taille_map"][1]
            #Creation de la map
            map = creer_map(largeur, hauteur)
            #Dimensionnement des images pour l'affichage de la map
            taille_case = configs["style"]["cases"].get_size()
            multiplicateur_horizontal = ((screen_size[0] - 2 * configs["offset"][0]) / configs["taille_map"][0]) / taille_case[0]
            multiplicateur_vertical = ((configs["limite_y"] - 2 * configs["offset"][1]) / configs["taille_map"][1]) / taille_case[1]
            if multiplicateur_horizontal > multiplicateur_vertical:
                multiplicateur = multiplicateur_vertical
            else:
                multiplicateur = multiplicateur_horizontal
            configs["style"]["cases"] = pygame.transform.scale(configs["style"]["cases"], (taille_case[0] * multiplicateur, taille_case[1] * multiplicateur))
            configs["style"]["cases_suppr"] = pygame.transform.scale(configs["style"]["cases_suppr"], (taille_case[0] * multiplicateur, taille_case[1] * multiplicateur))
            taille_tmp = configs["style"]["last_move_img"].get_size()
            configs["style"]["last_move_img"] = pygame.transform.scale(configs["style"]["last_move_img"], (taille_tmp[0] * multiplicateur, taille_tmp[1] * multiplicateur))
            poison_img = configs["style"]["case_poison"]
            poison_size = poison_img.get_size()
            multiplicateur = configs["style"]["cases"].get_size()[1] / poison_size[1]
            poison_img = pygame.transform.scale(poison_img, (poison_size[0] * multiplicateur, poison_size[1] * multiplicateur))
            #Fin du debut de la partie
            jouer["Premier lancement"] = False
        #Si fin de la partie
        if jouer["Fin"]:
            #Affichage du menu de fin
            screen.blit(configs["style"]["fond"], pos_fond)
            if jouer["Mode"] == "solo" or (jouer["Mode"] == "bac_a_sable" and jouer["Mode_Jc"] == "JcE"):
                if jouer["Joueur"] == 1:
                    joueur = "L'humain"
                else:
                    joueur = "L'IA"
                text = pavelt_font.render(f"{joueur} a perdu !", True, (0, 0, 0))
            elif jouer["Mode"] == "ai_vs_ai":
                joueur = jouer["Joueur"]
                text = pavelt_font.render(f"L'IA {joueur} a perdu !", True, (0, 0, 0))
            else:
                joueur = jouer["Joueur"]
                text = pavelt_font.render(f"Joueur {joueur} : Vous avez perdu !", True, (0, 0, 0))
            textRect = text.get_rect()
            pos_text = (screen_size[0] / 2 - textRect.width / 2, (screen_size[1] / 4) - textRect.height / 2)
            jouer["Afficher"] = True
            jouer["Afficher_content"] = (text, pos_text)
            selection_menu = 0
            menu = "fin"
        #Si miliue de partie
        #Si l'humain doit jouer
        if jouer["Mode"] == "multi" or (jouer["Mode"] == "bac_a_sable" and jouer["Mode_Jc"] == "JcJ"):
            tour_humain(configs["style"]["cases"], configs["style"]["cases_suppr"], poison_img, screen, screen_size, configs["style"]["fond"], pos_fond, configs["offset"], jouer["selection_map"], configs["style"]["selection"], pavelt_font, jouer, map, configs["style"]["last_move_img"])
        #Si l'ia doit jouer
        elif jouer["Mode"] == "solo" or (jouer["Mode"] == "bac_a_sable" and jouer["Mode_Jc"] == "JcE") or jouer["Mode"] == "ai_vs_ai":
            #Partie où au moins une IA fais son apparition
            if jouer["Joueur"] == 1 and not(jouer["Mode"] == "ai_vs_ai"):#Tour de l'humain
                tour_humain(configs["style"]["cases"], configs["style"]["cases_suppr"], poison_img, screen, screen_size, configs["style"]["fond"], pos_fond, configs["offset"], jouer["selection_map"], configs["style"]["selection"], pavelt_font, jouer, map, configs["style"]["last_move_img"])
            elif jouer["Joueur"] == 2 or jouer["Mode"] == "ai_vs_ai":#Tour de l'IA
                tour_ia(configs["style"]["cases"], configs["style"]["cases_suppr"], poison_img, screen, screen_size, configs["style"]["fond"], pos_fond, configs["offset"], configs["style"]["selection"], pavelt_font, jouer, map, jouer["last_move"], configs["style"]["last_move_img"], configs["style"]["son_suppr"])
    
    #Afficher les menus
    if menu != "empty":
        #Initialisation des informations utiles à l'affichage
        offset = 10
        img_title = None
        img_subtitle = None
        img_subtitle_size = None
        modif_size = False
        font = None
        largeur = None
        hauteur = None
        valeur3 = None
        pos_1 = None
        pos_2 = None
        pos_3 = None
        offset_text = None
        offset_text_spe = None
        img_selection_spe = None
        selection_speciale = False
        pos_selection_spe = None
        if menu == "main":
            liste_bouttons = [boutton_jouer_img, boutton_options_img, boutton_stats_img, boutton_quitter_img]
            offset = 281 / 2
            img_title = chomp3D_img
            img_subtitle = configs["style"]["titre"]
            img_subtitle_size = configs["style"]["titre_size"]
        elif menu == "play":
            liste_bouttons = [boutton_solo_img, boutton_multi_img, boutton_aivsai_img, boutton_bacasable_img, boutton_retour_img]
        elif menu == "difficulties":
            liste_bouttons = [boutton_taille_img, boutton_facile_img, boutton_moyen_img, boutton_difficile_img, boutton_retour_img]
            modif_size = True
            font = pavelt_font
            largeur = configs["taille_map"][0]
            hauteur = largeur
            pos_1 = 0
            offset_text = 175
        elif menu == "options":
            liste_bouttons = [boutton_son_img, boutton_style_img, boutton_largeur_img, boutton_hauteur_img, boutton_delai_img, boutton_retour_img]
            modif_size = True
            font = pavelt_font
            largeur = configs["taille_map"][0]
            hauteur = configs["taille_map"][1]
            valeur3 = configs["delai"]
            pos_1 = 2
            pos_2 = 3
            pos_3 = 4
            offset_text = 175
            offset_text_spe = 150
        elif menu == "styles":
            liste_bouttons = [pygame.transform.scale(classique_style_img, (200, 113)), pygame.transform.scale(chompagne_style_img, (200, 113)), pygame.transform.scale(chompignon_style_img, (200, 113)), boutton_retour_img]
            buttons_size = (200, 113)
        elif menu == "fin":
            liste_bouttons = [boutton_suivant_img]
        elif menu == "bac_a_sable":
            liste_bouttons = [boutton_jcj_img, boutton_jce_img, boutton_largeur_img, boutton_hauteur_img, boutton_suivant_img, boutton_retour_img]
            modif_size = True
            font = pavelt_font
            largeur = configs["taille_map"][0]
            hauteur = configs["taille_map"][1]
            pos_1 = 2
            pos_2 = 3
            offset_text = 175
            selection_speciale = True
            img_selection_spe = selection_bouttons_img
            if jouer["Mode_Jc"] == "JcJ":
                pos_selection_spe = 0
            elif jouer["Mode_Jc"] == "JcE":
                pos_selection_spe = 1
        elif menu == "ai_vs_ai":
            liste_bouttons = [boutton_ai1_img, boutton_ai2_img, boutton_suivant_img, boutton_retour_img]
            modif_size = True
            font = pavelt_font
            largeur = convertir_ia_diff_to_str(jouer["AI 1"])
            hauteur = convertir_ia_diff_to_str(jouer["AI 2"])
            pos_1 = 0
            pos_2 = 1
            offset_text = 85
        elif menu == "son":
            menu_son = True
            modifier_volumes(jouer)
        #Efface l'ecran en mettant l'image de fond
        screen.blit(configs["style"]["fond"], pos_fond)
        #Affichage exceptionnel
        if jouer["Afficher"]:
            screen.blit(jouer["Afficher_content"][0], jouer["Afficher_content"][1])
        #Si il n'y a pas d'autre affichage exceptionnel a faire
        if not(stats) and not(menu_son):
            liste_pos = list(afficher_menu(liste_bouttons, screen_size, buttons_size, screen, offset, img_title, img_subtitle, img_subtitle_size, modif_size, font, largeur, hauteur, valeur3, pos_1, pos_2, pos_3, offset_text, offset_text_spe, img_selection_spe, selection_speciale, pos_selection_spe))
            afficher_selection_menu(selection_menu_img, selection_menu, liste_pos, screen_size, buttons_size, screen)
        #Gestions des menus exceptionnels
        #Menu stats
        elif stats:
            text_winrate = pavelt_font.render(f"Winrate : {configs['winrate']}%", True, (0, 0, 0))
            if jouer["logs_games"] == []:
                text_streak = "Aucune info pour le moment"
            else:
                streak = win_lose_streak(jouer["logs_games"])
                configs["streak"] = streak
                if streak[0] == 1:
                    text_streak = f"Win streak : {streak[1]}"
                else:
                    text_streak = f"Lose streak : {streak[1]}"
            text_streak = pavelt_font.render(text_streak, True, (0, 0, 0))
            text_elo = pavelt_font.render(f"elo : {str(jouer['elo'])}", True, (0, 0, 0))
            text_winrate_Rect = text_winrate.get_rect()
            text_streak_Rect = text_streak.get_rect()
            text_elo_Rect = text_elo.get_rect()
            pos_winrate = (screen_size[0] / 2 - text_winrate_Rect.width / 2, screen_size[1] / 6 - text_winrate_Rect.height / 2)
            pos_streak = (screen_size[0] / 2 - text_streak_Rect.width / 2, (screen_size[1] / 6) * 2 - text_streak_Rect.height / 2)
            pos_elo = (screen_size[0] / 2 - text_elo_Rect.width / 2, (screen_size[1] / 6) * 3 - text_elo_Rect.height / 2)
            pos_reset = (screen_size[0] / 2 - buttons_size[0] / 2, (screen_size[1] / 6) * 4 - buttons_size[1] / 2)
            pos_retour = (screen_size[0] / 2 - buttons_size[0] / 2, (screen_size[1] / 6) * 5 - buttons_size[1] / 2)
            screen.blit(text_winrate, pos_winrate)
            screen.blit(text_streak, pos_streak)
            screen.blit(text_elo, pos_elo)
            screen.blit(boutton_reset_img, pos_reset)
            screen.blit(boutton_retour_img, pos_retour)
            liste_pos = [pos_reset, pos_retour]
            afficher_selection_menu(selection_menu_img, selection_menu, liste_pos, screen_size, buttons_size, screen)
        #Menu son
        elif menu_son:
            #------Afficher menu------
            #Preparation des elements necessaires a l'affichage
            text_music = pavelt_font.render("Musique", True, (0, 0, 0))
            text_vfx = pavelt_font.render("Effets", True, (0, 0, 0))
            text_music_Rect = text_music.get_rect()
            text_vfx_Rect = text_vfx.get_rect()
            taille_jauges = boutton_son_vide_img.get_size()
            taille_fleches = boutton_son_gauche_img.get_size()
            offset_fleches = 10
            division_de_screen = (screen_size[1] / 6)
            #Gestion des positions pour les jauges
            pos_jauges_music = []
            for i in range(1, 9):
                pos_jauges_music.append((screen_size[0] / 2 - buttons_size[0] / 2 + (buttons_size[0] / 9) * i - taille_jauges[0] / 2, division_de_screen * 2 - taille_jauges[1] / 2))
            pos_jauges_vfx = []
            for i in range(1, 9):
                pos_jauges_vfx.append((screen_size[0] / 2 - buttons_size[0] / 2 + (buttons_size[0] / 9) * i - taille_jauges[0] / 2, division_de_screen * 4 - taille_jauges[1] / 2))
            #Gestion des positions pour les textes
            pos_text_music = (screen_size[0] / 2 - text_music_Rect.width / 2, division_de_screen * 1 - text_music_Rect.height / 2)
            pos_text_vfx = (screen_size[0] / 2 - text_vfx_Rect.width / 2, division_de_screen * 3 - text_vfx_Rect.height / 2)
            #Gestion des positions pour les images des flèches
            pos_fleche_gauche_music = (screen_size[0] / 2 - buttons_size[0] / 2 - offset_fleches - taille_fleches[0] / 2, division_de_screen * 2 - taille_fleches[1] / 2)
            pos_fleche_droite_music = (screen_size[0] / 2 + buttons_size[0] / 2 + offset_fleches - taille_fleches[0] / 2, division_de_screen * 2 - taille_fleches[1] / 2)
            pos_fleche_gauche_vfx = (screen_size[0] / 2 - buttons_size[0] / 2 - offset_fleches - taille_fleches[0] / 2, division_de_screen * 4 - taille_fleches[1] / 2)
            pos_fleche_droite_vfx = (screen_size[0] / 2 + buttons_size[0] / 2 + offset_fleches - taille_fleches[0] / 2, division_de_screen * 4 - taille_fleches[1] / 2)
            #Gestion des positions pour le bouton retour
            pos_bouton_retour = (screen_size[0] / 2 - buttons_size[0] / 2, division_de_screen * 5 - buttons_size[1] / 2)
            #Affichage des textes
            screen.blit(text_music, pos_text_music)
            screen.blit(text_vfx, pos_text_vfx)
            #Affichage des flèches
            screen.blit(boutton_son_gauche_img, pos_fleche_gauche_music)
            screen.blit(boutton_son_gauche_img, pos_fleche_gauche_vfx)
            screen.blit(boutton_son_droite_img, pos_fleche_droite_music)
            screen.blit(boutton_son_droite_img, pos_fleche_droite_vfx)
            #Affichage du bouton retour
            screen.blit(boutton_retour_img, pos_bouton_retour)
            #Affichage des jauges
            #musique
            for i in range(len(pos_jauges_music)):
                if i * 0.125 < jouer["son_music"]:
                    img_jauge = boutton_son_rempli_img
                else:
                    img_jauge = boutton_son_vide_img
                screen.blit(img_jauge, pos_jauges_music[i])
            #effets
            for i in range(len(pos_jauges_vfx)):
                if i * 0.125 < jouer["son_vfx"]:
                    img_jauge = boutton_son_rempli_img
                else:
                    img_jauge = boutton_son_vide_img
                screen.blit(img_jauge, pos_jauges_vfx[i])
            #------Afficher selection------
            #Preparation des elements necessaires
            offset_selection = 10
            taille_selection = selection_menu_img.get_size()
            #Preparation des positions
            liste_pos_menu_son = [pos_text_music, pos_fleche_gauche_music, pos_text_vfx, pos_fleche_gauche_vfx, pos_bouton_retour]
            #Preparation des positions de la selection
            if selection_menu != 2:
                if selection_menu == 0:
                    pos_selection_gauche = (pos_fleche_gauche_music[0] - offset_selection - taille_selection[0] / 2, division_de_screen * 2 - taille_selection[1] / 2)
                    pos_selection_droite = (pos_fleche_droite_music[0] + taille_jauges[0] + offset_selection + taille_selection[0], division_de_screen * 2 - taille_selection[1] / 2)
                elif selection_menu == 1:
                    pos_selection_gauche = (pos_fleche_gauche_vfx[0] - offset_selection - taille_selection[0] / 2, division_de_screen * 4 - taille_selection[1] / 2)
                    pos_selection_droite = (pos_fleche_droite_vfx[0] + taille_jauges[0] + offset_selection + taille_selection[0], division_de_screen * 4 - taille_selection[1] / 2)
            elif selection_menu == 2:
                pos_selection_gauche = (screen_size[0] / 2 - buttons_size[0] / 2 - offset_selection - taille_selection[0] / 2, pos_bouton_retour[1] + buttons_size[1] / 2 - taille_selection[1] / 2)
                pos_selection_droite = (screen_size[0] / 2 + buttons_size[0] / 2 + offset_selection - taille_selection[0] / 2, pos_bouton_retour[1] + buttons_size[1] / 2 - taille_selection[1] / 2)
            #Affichage
            screen.blit(selection_menu_img, pos_selection_gauche)
            screen.blit(pygame.transform.rotate(selection_menu_img, 180), pos_selection_droite)
            liste_pos = [0, 0, 0]        
    
    #Fais bouger le fond
    if pos_fond[0] >= 0:
        pos_fond[0] = -64
    else:
        pos_fond[0] += 1 * speed
    if pos_fond[1] >= 0:
        pos_fond[1] = -64
    else:
        pos_fond[1] += 1 * speed
    
    #Bride les fps à 60
    clock.tick(60)
    #Afficher le contenu de la fenetre
    pygame.display.flip()

#Fermer le module pygame
pygame.quit()

#Sauvegarde des données
configs["elo"] = jouer["elo"]
configs["logs_games"] = jouer["logs_games"]
if configs["style"] == classique:
    save_str = "classique"
elif configs["style"] == chompagne:
    save_str = "chompagne"
elif configs["style"] == chompignon:
    save_str = "chompignon"
configs["style"] = save_str
configs["winrate"] = ratio_vd(jouer["logs_games"])
configs["son_music"] = jouer["son_music"]
configs["son_vfx"] = jouer["son_vfx"]
save(configs, "configs.chomp")

#Fin du programme
